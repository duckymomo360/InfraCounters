#pragma once

void ConfigureImGui();

void DrawImGui();
